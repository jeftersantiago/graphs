#ifndef _util_
#define _util_
#include <vector>
using namespace std;
struct Node {
  int index;
  int status;
  int d;
  int low;
  vector<Node *> adjacent;
};
#endif

