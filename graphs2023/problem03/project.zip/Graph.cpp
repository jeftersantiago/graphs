#include "Graph.hpp"
#include <iostream>
#include <stack>

#define UNDISCOVERED 0
#define DISCOVERED 1
#define PROCESSED 2

Graph::Graph(int v, bool directed) {
  V = 0;
  this->directed = directed;
  for (int i = 0; i < v; i++)
    addNode(i);
}

Graph::~Graph() {
  for (const auto &node : nodes)
    delete node;
}

vector<Node *> Graph::neighbours(int v) { return nodes[v]->adjacent; }

void Graph::addNode(int data) {
  Node *newNode = new Node;
  newNode->index = data;
  newNode->status = data;
  newNode->d = -1;
  newNode->low = -1;
  nodes.push_back(newNode);
  V++;
}
void Graph::addEdge(int i, int j) {
  nodes[i]->adjacent.push_back(nodes[j]);
  if (!directed)
    nodes[j]->adjacent.push_back(nodes[i]);
}

void Graph::print() {
  cout << endl;
  cout << "Adjacency List: " << endl;
  for (int i = 0; i < (int)nodes.size(); i++) {
    cout << "i = " << i << ": ";
    vector<Node *> adj = neighbours(i);
    for (int j = 0; j < (int)adj.size(); j++)
      cout << adj[j]->status << " ";
    cout << endl;
  }
}

vector<vector<int>> Graph::findSCCs() {
  vector<vector<int>> scc;
  vector<bool> onstack((int)nodes.size(), false);
  stack<Node*> st;

  for(Node * u : nodes){
    if(u->d == -1){
      tarjan(u, scc, st, onstack);
    }
  }
  return scc;
}

void Graph::tarjan(Node *u, vector<vector<int>> &scc, stack<Node *> & st, vector<bool> &onstack) {

  // cout << u->index << endl;

  u->d = u->low = t++;

  st.push(u);
  onstack[u->index] = true;

  for (Node *w : u->adjacent) {
    if (w->d == -1) {
      tarjan(w, scc, st, onstack);
      u->low = min(u->low, w->low);
    } else if (onstack[w->index]) {
      u->low = min(u->low, w->d);
    }
  }
  if(u->d == u->low){
    vector<int> scc_aux;
    Node * v;
    do {
      v = st.top();
      st.pop();
      onstack[v->index] = false;
      scc_aux.push_back(v->index);
    } while(v != u);
    scc.push_back(scc_aux);
  }
}
