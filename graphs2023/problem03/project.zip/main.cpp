#include "Graph.hpp"
#include <iostream>
#include <stdio.h>
#include <algorithm>

Graph read_graph();
void sort_sccs(vector<vector<int>> & sccs);
void print_sccs(vector<vector<int>> & sccs);

int main() {
  Graph g = read_graph();

  // g.print();

  vector<vector<int>> sccs = g.findSCCs();
  //  cout << "SCCS.size() = " << (int) sccs.size() << endl;
  cout << (int) sccs.size() << endl;
  //  cout << "SCCS" << endl;
  //  print_sccs(sccs);
  //  cout << "Sorted SCCS" << endl;
  sort_sccs(sccs);
  print_sccs(sccs);

  return 0;
}

void sort_sccs(vector<vector<int>> & sccs){
  for(int i = 0; i < (int) sccs.size(); i++)
    sort(sccs[i].begin(), sccs[i].end());
  sort(sccs.begin(), sccs.end());
}

void print_sccs(vector<vector<int>> & sccs){
  for(int i = 0; i < (int) sccs.size(); i++){
    for(int j = 0; j < (int) sccs[i].size(); j++){
      cout << sccs[i][j] << " ";
    }
    cout << endl;
  }
}



Graph read_graph() {
  int v = -1;
  int e = -1;
  int i, j;

  scanf("%d %d", &v, &e);

  Graph g(v, true);

  while (e > 0) {
    scanf("%d %d", &i, &j);
    g.addEdge(i, j);
    e--;
  }
  return g;
}
